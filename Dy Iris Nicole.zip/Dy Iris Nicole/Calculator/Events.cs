﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Calculator
{
    public class Events : IEvents
    {
        readonly IDataUtility dataUtility;
        List<string> memoryTrail;

        public Events()
        {
            this.dataUtility = new DataUtility();
            memoryTrail = new List<string>();
        }

        public string One(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "1");

            return current;
        }

        public string Two(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "2");

            return current;
        }

        public string Three(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "3");

            return current;
        }

        public string Four(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "4");

            return current;
        }

        public string Five(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "5");

            return current;
        }

        public string Six(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "6");

            return current;
        }

        public string Seven(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "7");

            return current;
        }

        public string Eight(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "8");

            return current;
        }

        public string Nine(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "9");

            return current;
        }

        public string Zero(string current)
        {
            if (dataUtility.IsLengthValid(current))
                return dataUtility.FormatTextWithComma(current + "0");

            return current;
        }

        public string Negate(string current)
        {
            if (dataUtility.IsLengthValid(current))
            {
                if (current.StartsWith("-"))
                    return dataUtility.FormatTextWithComma(current.Replace("-", ""));
                else
                    return dataUtility.FormatTextWithComma("-" + current);
            }
            return current;
        }

        public string Decimal(string current)
        {
            if (dataUtility.IsLengthValid(current) && !current.Contains("."))
            {
                current = String.IsNullOrEmpty(current) ? "0" : current;
                return dataUtility.FormatTextWithComma(current + ".");
            }
            return current;
        }

        public string Delete(string current)
        {
            if (current.Length != 0)
                return dataUtility.FormatTextWithComma(current.Remove(current.Length - 1, 1));

            return current;
        }

        public void Equal(
            string operatorCB,
            ref string current,
            ref Queue equationQueue,
            ref Queue equalHistoryQueue,
            ref string tempValue,
            ref string tb_CurrentEquation,
            ref string tb_NewEntry)
        {
            if (string.IsNullOrEmpty(current))
            {
                if (equationQueue.Count > 0)
                {
                    decimal _operand = decimal.Parse(equationQueue.Peek().ToString());
                    equationQueue.Dequeue();
                    string _operator = equationQueue.Peek() as string;
                    equationQueue.Dequeue();

                    if (!string.IsNullOrEmpty(_operator))
                    {
                        equalHistoryQueue = new Queue();
                        equalHistoryQueue.Enqueue(_operand);
                        equalHistoryQueue.Enqueue(_operator);
                    }

                    equationQueue = new Queue(equalHistoryQueue);
                    current = string.IsNullOrEmpty(tempValue) ? "0" : tempValue;
                }
            }
            dataUtility.Compute(
                operatorCB,
                ref equationQueue,
                ref equalHistoryQueue,
                ref current,
                ref tb_CurrentEquation,
                ref tb_NewEntry,
                ref tempValue);
        }

        public (List<string> list, string tb_NewEntryText) MemorySave(string tb_NewEntry)
        {
            if (string.IsNullOrEmpty(tb_NewEntry))
                tb_NewEntry = "0";

            memoryTrail.Insert(0, dataUtility.FormatTextWithComma(tb_NewEntry));

            return (memoryTrail, tb_NewEntry);
        }

        public List<string> MemoryPlus(string tb_NewEntry)
        {
            decimal lastMemory = 0;
            if (memoryTrail.Count > 0)
            {
                lastMemory = decimal.Parse(memoryTrail[0]);
                memoryTrail.RemoveAt(0);
            }
            decimal newValue = decimal.Parse(tb_NewEntry) + lastMemory;
            memoryTrail.Insert(0, dataUtility.FormatTextWithComma(newValue.ToString()));

            return memoryTrail;
        }

        public List<string> MemoryMinus(string tb_NewEntry)
        {
            decimal lastMemory = 0;
            if (memoryTrail.Count > 0)
                lastMemory = decimal.Parse(memoryTrail[0]);

            decimal newValue = lastMemory - decimal.Parse(tb_NewEntry);
            memoryTrail.RemoveAt(0);
            memoryTrail.Insert(0, dataUtility.FormatTextWithComma(newValue.ToString()));

            return memoryTrail;
        }

        public List<string> MemoryClear()
        {
            memoryTrail.Clear();
            return memoryTrail;
        }

        public string MemoryRecall()
        {
            decimal lastMemory = 0;
            if (memoryTrail.Count > 0)
                lastMemory = decimal.Parse(memoryTrail[0]);

            return dataUtility.FormatTextWithComma(lastMemory.ToString());
        }

        public void OperatorChange(
           string OperatorCb,
            ref string currentValue,
            ref Queue equationQueue,
            ref Queue equalHistoryQueue,
            ref string tempValue,
            ref string tb_CurrentEquation,
            ref string tb_NewEntry
            )
        {
            if (!String.IsNullOrEmpty(currentValue))
            {
                dataUtility.Compute(
                   OperatorCb,
                   ref equationQueue,
                   ref equalHistoryQueue,
                   ref currentValue,
                   ref tb_CurrentEquation,
                   ref tb_NewEntry,
                   ref tempValue);
            }
            else
            {
                // Change value of Operator
                if (equationQueue.Count > 0)
                {
                    // Change value of equationQueue
                    decimal _operand = decimal.Parse(equationQueue.Peek().ToString());
                    equationQueue.Clear();
                    equationQueue.Enqueue(_operand);
                    equationQueue.Enqueue(OperatorCb);

                    if (equalHistoryQueue.Count > 0)
                    {
                        // Change value of equalHistoryQueue
                        decimal _operandEqual = decimal.Parse(equalHistoryQueue.Peek().ToString());
                        equalHistoryQueue.Clear();
                        equalHistoryQueue.Enqueue(_operandEqual);
                        equalHistoryQueue.Enqueue(OperatorCb);
                    }

                    tb_CurrentEquation = string.Format("{0} {1} ", _operand, OperatorCb);
                }
                else
                {
                    equationQueue.Enqueue(0);
                    equationQueue.Enqueue(OperatorCb);
                    tb_CurrentEquation = string.Format("{0} {1} ", "0", OperatorCb);
                }
            }
        }

    }
}
