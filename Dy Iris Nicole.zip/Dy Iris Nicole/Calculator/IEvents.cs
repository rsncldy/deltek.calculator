﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Calculator
{
    public interface IEvents
    {
        string One(string current);
        string Two(string current);
        string Three(string current);
        string Four(string current);
        string Five(string current);
        string Six(string current);
        string Seven(string current);
        string Eight(string current);
        string Nine(string current);
        string Zero(string current);
        string Negate(string current);
        string Decimal(string current);
        string Delete(string current);
        void Equal(
            string operatorCB,
            ref string current,
            ref Queue equationQueue,
            ref Queue equalHistoryQueue,
            ref string tempValue,
            ref string tb_CurrentEquation,
            ref string tb_NewEntry);
        (List<string> list, string tb_NewEntryText) MemorySave(string tb_NewEntry);
        List<string> MemoryPlus(string tb_NewEntry);
        List<string> MemoryMinus(string tb_NewEntry);
        List<string> MemoryClear();
        string MemoryRecall();
    }
}
