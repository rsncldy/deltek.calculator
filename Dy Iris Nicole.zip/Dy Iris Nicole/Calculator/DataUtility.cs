﻿using System;
using System.Collections;

namespace Calculator
{
    public class DataUtility : IDataUtility
    {
        public bool IsLengthValid(string current)
        {
            return current.Length + 1 > 21 ? false : true;
        }

        public string FormatTextWithComma(string current)
        {
            if (!String.IsNullOrEmpty(current) && !current.Equals("-"))
                return String.Format("{0:n0}", decimal.Parse(current));
            return string.Empty;
        }

        public void 
            Compute(
            string operatorCB,
            ref Queue equationQueue,
            ref Queue equalHistoryQueue,
            ref string current,
            ref string tb_CurrentEquation,
            ref string tb_NewEntry,
            ref string tempValue)
        {
            decimal result;
            if (equationQueue.Count > 0)
            {
                decimal _operand = decimal.Parse(equationQueue.Peek().ToString());
                equationQueue.Dequeue();
                string _operator = equationQueue.Peek() as string;
                equationQueue.Dequeue();
                string selectedOperator = operatorCB;
                try
                {
                    switch (_operator)
                    {
                        case "+":
                            result = _operand + decimal.Parse(current);
                            break;
                        case "-":
                            result = _operand - decimal.Parse(current);
                            break;
                        case "/":
                            result = _operand / decimal.Parse(current);
                            break;
                        case "*":
                            result = _operand * decimal.Parse(current);
                            break;
                        default:
                            result = 0;
                            break;
                    }
                    equationQueue.Enqueue(result);
                    equationQueue.Enqueue(operatorCB);
                    _operator = string.IsNullOrEmpty(selectedOperator) ? _operator : selectedOperator;
                    tb_CurrentEquation = string.Format("{0} {1} {2} ", _operand, _operator, current);

                    if (equalHistoryQueue.Count > 0)
                    {
                        equalHistoryQueue.Dequeue();
                        _operator = equalHistoryQueue.Peek().ToString();
                        equalHistoryQueue.Dequeue();
                    }
                    equalHistoryQueue.Enqueue(result.ToString());
                    equalHistoryQueue.Enqueue(_operator);
                    tb_NewEntry = result.ToString();
                    tempValue = current;
                    current = string.Empty;
                }
                catch (Exception x)
                {
                    equationQueue.Clear();
                    tb_NewEntry = "ERROR";
                    tb_CurrentEquation = string.Empty;
                    tempValue = string.Empty;
                    current = string.Empty;
                }

            }
            else if (!string.IsNullOrEmpty(current) && !(operatorCB == null))
            {
                equationQueue.Enqueue(current);
                equationQueue.Enqueue(operatorCB);
                tb_CurrentEquation = string.Format("{0} {1} ", current, operatorCB);
                tb_NewEntry = current;
                tempValue = string.Empty;
            }
        }

    }
}
