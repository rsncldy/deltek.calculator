﻿using System;
using System.Collections;

namespace Calculator
{
    public interface IDataUtility
    {
        bool IsLengthValid(string current);
        string FormatTextWithComma(string current);
        void Compute(
            string operatorCB,
            ref Queue equationQueue,
            ref Queue equalHistoryQueue,
            ref string current,
            ref string tb_CurrentEquation,
            ref string tb_NewEntry,
            ref string tempValue);
    }
}
