﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string currentValue;
        string tempValue;
        Queue equationQueue;
        Queue equalHistoryQueue;
        readonly IEvents events;

        public MainWindow()
        {
            InitializeComponent();
            tb_NewEntry.TextAlignment = TextAlignment.Right;
            tb_NewEntry.VerticalAlignment = VerticalAlignment.Bottom;
            tb_CurrentEquation.TextAlignment = TextAlignment.Right;
            tb_CurrentEquation.VerticalAlignment = VerticalAlignment.Top;
            tb_NewEntry.Text = "0";
            currentValue = string.Empty;
            tempValue = string.Empty;
            equationQueue = new Queue();
            equalHistoryQueue = new Queue();
            events = new Events();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.D0 || e.Key == Key.NumPad0)
            {
                tb_NewEntry.Text = events.Zero(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D1 || e.Key == Key.NumPad1)
            {
                tb_NewEntry.Text = events.One(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D2 || e.Key == Key.NumPad2)
            {
                tb_NewEntry.Text = events.Two(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D3 || e.Key == Key.NumPad3)
            {
                tb_NewEntry.Text = events.Three(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D4 || e.Key == Key.NumPad4)
            {
                tb_NewEntry.Text = events.Four(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D5 || e.Key == Key.NumPad5)
            {
                tb_NewEntry.Text = events.Five(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D6 || e.Key == Key.NumPad6)
            {
                tb_NewEntry.Text = events.Six(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D7 || e.Key == Key.NumPad7)
            {
                tb_NewEntry.Text = events.Seven(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D8 || e.Key == Key.NumPad8)
            {
                tb_NewEntry.Text = events.Eight(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.D9 || e.Key == Key.NumPad9)
            {
                tb_NewEntry.Text = events.Nine(currentValue);
                currentValue = tb_NewEntry.Text;
            }
            else if (e.Key == Key.Enter)
            {
                string tb_CurrentEquationText = tb_CurrentEquation.Text;
                string tb_NewEntryText = tb_NewEntry.Text;
                string _operator = OperatorCb.SelectedValue as string;
                events.Equal(
                    _operator,
                    ref currentValue,
                    ref equationQueue,
                    ref equalHistoryQueue,
                    ref tempValue,
                    ref tb_CurrentEquationText,
                    ref tb_NewEntryText);

                tb_CurrentEquation.Text = tb_CurrentEquationText;
                tb_NewEntry.Text = tb_NewEntryText;
            }
            else if (e.Key == Key.Back)
            {
                tb_NewEntry.Text = events.Delete(currentValue);
                currentValue = tb_NewEntry.Text;
            }
        }

        #region Menu
        private void FileMenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void EditMenu_Click(object sender, RoutedEventArgs e)
        {

        }

        private void HistoryMenu_Click(object sender, RoutedEventArgs e)
        {

        }
        #endregion

        #region Buttons 0 to 9
        private void OneButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.One(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void TwoButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Two(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void ThreeButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Three(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void FourButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Four(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void FiveButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Five(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void SixButton_Click(object sender, RoutedEventArgs e)
        {

            tb_NewEntry.Text = events.Six(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void SevenButton_Click(object sender, RoutedEventArgs e)
        {

            tb_NewEntry.Text = events.Seven(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void EightButton_Click(object sender, RoutedEventArgs e)
        {

            tb_NewEntry.Text = events.Eight(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void NineButton_Click(object sender, RoutedEventArgs e)
        {

            tb_NewEntry.Text = events.Nine(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {

            tb_NewEntry.Text = events.Zero(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        #endregion

        #region Other buttons
        private void NegateButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Negate(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void DecimalButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Decimal(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void CButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = string.Empty;
            tb_CurrentEquation.Text = string.Empty;
            currentValue = string.Empty;
            equationQueue.Clear();
            equalHistoryQueue.Clear();
        }

        private void DelButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.Delete(currentValue);
            currentValue = tb_NewEntry.Text;
        }

        private void EqualButton_Click(object sender, RoutedEventArgs e)
        {
            string tb_CurrentEquationText = tb_CurrentEquation.Text;
            string tb_NewEntryText = tb_NewEntry.Text;
            string _operator = OperatorCb.SelectedValue as string;
            events.Equal(
                _operator,
                ref currentValue,
                ref equationQueue,
                ref equalHistoryQueue,
                ref tempValue,
                ref tb_CurrentEquationText,
                ref tb_NewEntryText);

            tb_CurrentEquation.Text = tb_CurrentEquationText;
            tb_NewEntry.Text = tb_NewEntryText;
        }
        #endregion

        #region Memory
        private void MsButton_Click(object sender, RoutedEventArgs e)
        {
            (List<string> list, string tb_NewEntryText) = events.MemorySave(tb_NewEntry.Text);
            Listbox_Memory.ItemsSource = list;
            Listbox_Memory.Items.Refresh();
            tb_NewEntry.Text = tb_NewEntryText;
        }

        private void MPlusButton_Click(object sender, RoutedEventArgs e)
        {
            Listbox_Memory.ItemsSource = events.MemoryPlus(tb_NewEntry.Text);
            Listbox_Memory.Items.Refresh();
        }

        private void MMinusButton_Click(object sender, RoutedEventArgs e)
        {
            Listbox_Memory.ItemsSource = events.MemoryMinus(tb_NewEntry.Text);
            Listbox_Memory.Items.Refresh();
        }

        private void McButton_Click(object sender, RoutedEventArgs e)
        {
            Listbox_Memory.ItemsSource = events.MemoryClear();
            Listbox_Memory.Items.Refresh();
        }

        private void MrButton_Click(object sender, RoutedEventArgs e)
        {
            tb_NewEntry.Text = events.MemoryRecall();
        }
        #endregion

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!OperatorCb.SelectedIndex.Equals(-1))
            {
                string tb_CurrentEquationText = tb_CurrentEquation.Text;
                string tb_NewEntryText = tb_NewEntry.Text;
                string _operator = OperatorCb.SelectedValue as string;
                events.Equal(
                    _operator,
                    ref currentValue,
                    ref equationQueue,
                    ref equalHistoryQueue,
                    ref tempValue,
                    ref tb_CurrentEquationText,
                    ref tb_NewEntryText);

                tb_CurrentEquation.Text = tb_CurrentEquationText;
                tb_NewEntry.Text = tb_NewEntryText;
            }
        }

        private void ComboBox_Reset(object sender, EventArgs e)
        {
            OperatorCb.SelectedIndex = -1;
            OperatorCb.Text = "";
        }

        private void Listbox_Memory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
